package com.assignment3;

import java.util.Scanner;

public class Question9 {
	
		public void rotateRight(int[] arr) {
	        int last = arr[arr.length - 1];
	        for (int i = arr.length - 1; i > 0; i--) {
	            arr[i] = arr[i - 1];
	        }
	        arr[0] = last;
	    }

	    public void rotateLeft(int[] arr) {
	        int first = arr[0];
	        for (int i = 0; i < arr.length - 1; i++) {
	            arr[i] = arr[i + 1];
	        }
	        arr[arr.length - 1] = first;
	    }

	    public void printArray(int[] arr) {
	        for (int num : arr) {
	            System.out.print(num + " ");
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        
	    	Question9 q= new Question9();
	    	
	    	Scanner sc = new Scanner(System.in);
	        
	        System.out.print("Enter the number of elements: ");
	        int n = sc.nextInt();
	        
	        int[] arr = new int[n];
	        System.out.println("Enter the elements:");
	        for (int i = 0; i < n; i++) {
	            arr[i] = sc.nextInt();
	        }

	        System.out.println("Original Array:");
	        q.printArray(arr);

	        q.rotateRight(arr);
	        System.out.println("Array after right rotation:");
	        q.printArray(arr);

	        System.out.println("Enter the elements again to reset:");
	        for (int i = 0; i < n; i++) {
	            arr[i] = sc.nextInt();
	        }

	        q.rotateLeft(arr);
	        System.out.println("Array after left rotation:");
	        q.printArray(arr);

	}

}
