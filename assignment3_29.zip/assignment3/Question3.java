package com.assignment3;

import java.util.Arrays;

public class Question3 {

	public static void main(String[] args) {
	
	
		int[]arr= {1,2,5,9,11};
		Arrays.sort(arr);
		System.out.println("second minimum: "+arr[1]);
		System.out.println("second maximum: "+arr[arr.length-2]);
		
		
	}
}
