package com.assignment3;

public class Question8 {

	public static void main(String[] args) {
		
		 int[] arr = {1, 2, 3, 4, 5, 6}; 
	        int evenN = 0;  
	        int oddN = 0;   

	        for (int num : arr) {
	            if (num % 2 == 0) {
	                evenN++;  
	            } else {
	                oddN++;   
	            }
	        }

	        System.out.println("Number of even elements: " + evenN);
	        System.out.println("Number of odd elements: " + oddN);

	}

}
