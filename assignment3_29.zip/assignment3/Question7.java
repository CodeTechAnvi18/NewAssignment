package com.assignment3;

import java.util.Arrays;
import java.util.Scanner;

public class Question7 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();
        
        int[] arr = new int[n];
        System.out.println("Enter the elements:");
        for (int i =0; i< n;i++) {
            arr[i] = sc.nextInt();
        }

        int m = n/2;

        Arrays.sort(arr, 0, m);

        Arrays.sort(arr, m, n);
        for (int i = m; i<n/2 + m;i++) {

        	int t = arr[i];
            arr[i] = arr[n - (i - m) - 1];
            arr[n - (i - m)- 1]= t;
        }

        System.out.println("Sorted Array: ");
        for (int num : arr) {
            System.out.print(num + " ");
        }

	}

}
